﻿using System;
namespace AttendanceDatabase.Models
{
	public class CategoryTags
	{
		public int Id { get; set; }
		public String TagName { get; set; }
		public int AttnCnt { get; set; }
	}
}

