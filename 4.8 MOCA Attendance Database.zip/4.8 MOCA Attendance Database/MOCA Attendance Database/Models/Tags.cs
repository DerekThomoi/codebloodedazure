﻿using System;
namespace MOCA_Attendance_Database.Models
{
    public class Tags
    {
        public int Id { get; set; }
        public String Name { get; set; }
    }
}

