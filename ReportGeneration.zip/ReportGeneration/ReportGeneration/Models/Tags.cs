﻿using System;
namespace ReportGeneration.Models
{
	public class Tags
	{
		public int Id { get; set; }
        public String Name { get; set; }
    }
}

