﻿using System.Data;
using System.Diagnostics;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReportGeneration.Models;


namespace Report_Generator_Form.Controllers;

public class FormController : Controller
{
    private readonly ILogger<FormController> _logger;
    private readonly AppDbContext _context;


    public FormController(ILogger<FormController> logger, AppDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult RP_Index()
    {
        
        var categoryTagCount = _context.Tags.Count();
        var categoryEventCount = _context.Categories.Count();

        
        ViewBag.CategoryTagCount = categoryTagCount;
        ViewBag.CategoryEventCount = categoryEventCount;

        ViewData["HideNavbar"] = true;

        return View();
        //return RedirectToAction("Staff_Index");
    }

    public IActionResult Staff_Index()
    {
        var categoryEventCount = _context.Categories.Count();
        ViewBag.CategoryEventCount = categoryEventCount;
        ViewData["HideNavbar"] = true;
        return View();
    }

        /*Creating Tags*/
        public IActionResult RP_CreateTags()
    {
        return View();
    }

    [HttpPost]
    public IActionResult RP_AddTags(Tags model)
    {
        _context.Tags.Add(model);
        _context.SaveChanges();
        return RedirectToAction("RP_ViewTags");
    }

    public IActionResult RP_ViewTags()
    {
        var tagList = _context.Tags.ToList();
        return View(tagList);
    }

    public IActionResult RP_DeleteTags(int id)
    {
        var tagInDb = _context.Tags.SingleOrDefault(tags => tags.Id == id); //find where an id in the Db matches the given id
        _context.Tags.Remove(tagInDb); //remove that expense from the DB
        _context.SaveChanges();
        return RedirectToAction("RP_ViewCategories");
    }


    /*Event Management*/

    public IActionResult RP_Category(int? id)
    {
        if (id != null)
        {//editing -> load an expense by id
            var categoryInDb = _context.Categories.SingleOrDefault(categories => categories.Id == id);
            return View(categoryInDb);
        }

        var newCategory = new Category
        {
            Tags = new List<CategoryTags>()
        };
        var availableTags = _context.Tags.ToList();

        var viewModel = new CategoryInfo
        {
            Category = newCategory,
            Tags = availableTags  // Set the list of tags
        };
        return View(viewModel);
    }

    /*Showing all categories in database*/
    public IActionResult RP_ViewCategories()
    {
        var categoryList = _context.Categories.Include(c => c.Tags).ToList();

        // Create a list to hold all tag names
        List<string> tagNames = new List<string>();

        // Add each tag's name to the list
        foreach (var category in categoryList)
        {
            foreach (var tag in category.Tags)
            {
                // Only add the tag if it's not already in the list
                if (!tagNames.Contains(tag.TagName))
                {
                    tagNames.Add(tag.TagName);
                }
            }
        }

        // Pass the list of tags to the view
        ViewBag.TagNames = tagNames;

        return View(categoryList);
    }


    /*Creating or editing a category*/
    [HttpPost]
    public IActionResult RP_AddEditCategoryForm(CategoryInfo model, string[] tags)
    {
        // If adding a new category
        if (model.Category.Id == 0)
        {
            // Check if any tags are selected
            if (tags != null && tags.Length > 0)
            {
                foreach (var tagName in tags)
                {
                    var newTag = new CategoryTags
                    {
                        TagName = tagName,
                        AttnCnt = 0
                    };

                    model.Category.Tags.Add(newTag);
                }
            }
            

            // Adding the new category to the DB
            _context.Categories.Add(model.Category);
        }
        else
        {
            // Edit existing category, making sure the tags are associated
            _context.Categories.Update(model.Category);
        }

        _context.SaveChanges();
        return RedirectToAction("RP_ViewCategories");
    }



    /*Deleting a category*/
    public IActionResult RP_DeleteCategory(int id)
    {
        var categoryInDb = _context.Categories.Include(c => c.Tags).SingleOrDefault(categories => categories.Id == id);

        if (categoryInDb != null)
        {
            // Remove the associated CategoryTags first
            _context.CategoryTags.RemoveRange(categoryInDb.Tags);

            // Then remove the category
            _context.Categories.Remove(categoryInDb);
            _context.SaveChanges();
        }

        return RedirectToAction("RP_ViewCategories");
    }


    /*Main Data Entry page*/
    public IActionResult EnterDate()
    {
        return View();
    }

    /*Searching for event by date*/
    [HttpPost]
    public IActionResult DataEntry(DateTime date)
    {
        var categories = _context.Categories.Include(c => c.Tags).Where(c => c.Date.Date == date.Date).ToList();

        return View(categories);

    }

    /*Saving Attendance Data*/
    [HttpPost]
    public IActionResult SaveAttendance(List<Category> categories)
    {
        if (categories.Count() > 0)
        {
            foreach (var category in categories)
            {
                // Retrieve the existing category from the database, including its tags
                var existingCategory = _context.Categories.Include(c => c.Tags).FirstOrDefault(c => c.Id == category.Id);

                if (existingCategory != null)
                {
                    // Update the TotAttn value (sum of attendance count)
                    existingCategory.TotAttn = category.Tags.Sum(tag => tag.AttnCnt);

                    // Update the AttnCnt for each tag in the category
                    foreach (var tag in category.Tags)
                    {
                        // Find the existing tag in the category
                        var existingTag = existingCategory.Tags.FirstOrDefault(t => t.Id == tag.Id);
                        if (existingTag != null)
                        {
                            // Only update the AttnCnt, leave TagName and other fields unchanged
                            existingTag.AttnCnt = tag.AttnCnt;

                            // Explicitly mark the CategoryTag entity as modified
                            _context.Entry(existingTag).State = EntityState.Modified;
                        }

                    }

                    // Ensure the category itself is updated
                    _context.Categories.Update(existingCategory);
                }
            }

            // Save the changes to the database
            _context.SaveChanges();
        }

        return RedirectToAction("RP_Index"); // Or wherever you want to redirect after saving
    }









    //REPORT GENERATION

    /*Showing filtered categories based on the given requirements*/

    public IActionResult RP_ViewPastCategories(List<String> selectedTags,string? selectedName,DateTime? startDate,DateTime? endDate,bool? events,bool? programs,bool? cafes,int page = 1)
    {
        const int pageSize = 25;

        var filteredCategories = _context.Categories.AsQueryable();

        // Apply filters for Category Types
        if (events.HasValue)
            filteredCategories = filteredCategories.Where(c => c.Event == events.Value);

        if (programs.HasValue)
            filteredCategories = filteredCategories.Where(c => c.Program == programs.Value);

        if (cafes.HasValue)
            filteredCategories = filteredCategories.Where(c => c.Cafe == cafes.Value);

        // Apply filters for Date Range
        if (startDate.HasValue && endDate.HasValue)
            filteredCategories = filteredCategories.Where(c => c.Date >= startDate.Value && c.Date <= endDate.Value);

        // Apply filter for selected name
        if (!string.IsNullOrEmpty(selectedName))
            filteredCategories = filteredCategories.Where(c => c.Name.Contains(selectedName));

        // Apply filter for selected tags
        if (selectedTags != null && selectedTags.Any())
        {
            filteredCategories = filteredCategories.Where(c => c.Tags.Any(t => selectedTags.Contains(t.TagName)));
        }

        // Sort by Date in descending order
        filteredCategories = filteredCategories.OrderByDescending(c => c.Date);

        // Include related Tags while filtering
        var categoryInfoList = filteredCategories.Include(c => c.Tags).ToList()
            .Select(c => new CategoryInfo
            {
                Category = c,
                Tags = c.Tags.Select(ct => new Tags { Name = ct.TagName }).ToList()
            }).ToList();

        // Pagination logic
        var totalItems = categoryInfoList.Count();
        var totalPages = (int)Math.Ceiling(totalItems / (double)pageSize);

        var categoriesForCurrentPage = categoryInfoList.Skip((page - 1) * pageSize).Take(pageSize).ToList();

        // Pass pagination data along with category data to the view
        var model = new CategoryPaginationViewModel
        {
            Categories = categoriesForCurrentPage,
            CurrentPage = page,
            TotalPages = totalPages
        };

        return View(model);
    }


    /*Displays a bar graph and a Pie chart based on the data provided from selected Category Events*/
    public async Task<IActionResult> RP_VisualReportPage(string? selectedCategoryIds, List<int>? category)
    {
        List<Category> selectedCategories = new List<Category>();
        int totalAttn = 0;

        if (!string.IsNullOrEmpty(selectedCategoryIds))
        {
            var selectedIdsArray = selectedCategoryIds.Split(',');
            List<int> catList = selectedIdsArray.Select(id => int.TryParse(id, out var result) ? result : 0).ToList();
            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => catList.Contains(c.Id)).ToList();
        }
        else if (category != null && category.Any())
        {
            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => category.Contains(c.Id)).ToList();
        }

        // Check if selectedCategories contains any data
        if (selectedCategories.Count == 0)
        {
            // Handle empty categories case
            return View("Error", new { message = "No categories selected." });
        }

        // Total Attendance Calculation
        totalAttn = selectedCategories.Sum(c => c.TotAttn);

        List<CategoryTags> pieData = new List<CategoryTags>();

        foreach (var cat in selectedCategories)
        {

            foreach (var categoryTag in cat.Tags)
            {
                var existingTag = pieData.FirstOrDefault(pt => pt.TagName == categoryTag.TagName);

                if (existingTag != null)
                {
                    existingTag.AttnCnt += categoryTag.AttnCnt;
                }
                else
                {
                    pieData.Add(new CategoryTags
                    {
                        TagName = categoryTag.TagName,
                        AttnCnt = categoryTag.AttnCnt
                    });
                }
            }
        }

        // Pie Chart Data
        var pieChartData = pieData.Select(tag => new ChartDataViewModel
        {
            Tag = tag.TagName,      
            Count = tag.AttnCnt,
            Percentage = (double)tag.AttnCnt / totalAttn * 100
        }).ToList();

        
        // Bar Chart Data ordered chronologically
        var barChartData = selectedCategories.OrderBy(c => c.Date).ToList();

        // ViewBag Items for chart data
        ViewBag.TagCnt = _context.Tags.ToList().Count(); 
        ViewBag.CategoryCnt = selectedCategories.Count();
        ViewBag.TotCount = totalAttn;
        // Set ViewBag for pie chart
        ViewBag.PieChartTags = pieChartData.Select(c => c.Tag).ToArray();
        ViewBag.PieChartAttnCnts = pieChartData.Select(c => c.Count).ToArray();

        // Set ViewBag for bar chart
        ViewBag.BarChartNames = barChartData.Select(c => c.Name).ToArray();
        ViewBag.BarChartAttnCnts = barChartData.Select(c => c.TotAttn).ToArray();

        return View(pieChartData);
    }


    /*Gathering selected events to have their raw data downloaded to an Excel file*/
    public async Task<FileResult> RP_DownloadRawData(string? selectedCategoryIds, List<int>? category)
    {
        List<Category> selectedCategories = new List<Category>();
        int totalAttn = 0;

        if (!string.IsNullOrEmpty(selectedCategoryIds))
        {
            var selectedIdsArray = selectedCategoryIds.Split(',');
            List<int> catList = new List<int>();

            foreach (var item in selectedIdsArray)
            {
                int x = 0;
                Int32.TryParse(item, out x);
                catList.Add(x);
            }

            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => catList.Contains(c.Id)).ToList();
        }
        else if (category != null && category.Any())
        {
            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => category.Contains(c.Id)).ToList();
        }

        if (!selectedCategories.Any())
        {
            // Return an error file if no categories are selected.
            return File(new byte[0], "application/octet-stream", "NoCategoriesSelected.xlsx");
        }


        //Organize Tag Attendance Data

        // Total Attendance Calculation
        totalAttn = selectedCategories.Sum(c => c.TotAttn);

        List<CategoryTags> pieData = new List<CategoryTags>();

        foreach (var cat in selectedCategories)
        {
            foreach (var categoryTag in cat.Tags)
            {
                var existingTag = pieData.FirstOrDefault(pt => pt.TagName == categoryTag.TagName);

                if (existingTag != null)
                {
                    existingTag.AttnCnt += categoryTag.AttnCnt;
                }
                else
                {
                    pieData.Add(new CategoryTags
                    {
                        TagName = categoryTag.TagName,
                        AttnCnt = categoryTag.AttnCnt
                    });
                }
            }
        }

        


        //Organize Event Attendance Data

        string date = DateTime.Now.ToString("MM.dd.yyyy hh:mm");

        var fileName = date + "_Attendance_Data.xlsx";

        return GenerateExcel(fileName, selectedCategories, pieData);
    }
    
    /*Generating the Excel file to download to computer*/
    private FileResult GenerateExcel(string fileName, IEnumerable<Category> selectedCategories, List<CategoryTags> pieData)
    {
        DataTable dataTable = new DataTable("Category Attendance Data");
        dataTable.Columns.AddRange(new DataColumn[]{
        new DataColumn("Name"),
        new DataColumn("Date"),
        new DataColumn("Tags"),
        new DataColumn("Event"),
        new DataColumn("Program"),
        new DataColumn("Cafe"),
        new DataColumn("Attendance Count")
        });

        // Pie Chart Data
        DataTable pieChartDataTable = new DataTable("Tag Attendance Data");
        pieChartDataTable.Columns.AddRange(new DataColumn[] {
        new DataColumn("Tags"),
        new DataColumn("Attendance Count")
        });


        foreach (var pieTag in pieData)
        {
            pieChartDataTable.Rows.Add(pieTag.TagName, pieTag.AttnCnt);
        }

        foreach (var category in selectedCategories)
        {
            // Convert the list of tags to a comma-separated string
            string tags = category.Tags != null && category.Tags.Any() ? string.Join(", ", category.Tags.Select(t => t.TagName)) : "No Tags";

            dataTable.Rows.Add(
                category.Name,
                category.Date.ToString("MM/dd/yyyy"),
                tags,
                category.Event ? "Yes" : "No",
                category.Program ? "Yes" : "No",
                category.Cafe ? "Yes" : "No",
                category.TotAttn
            );
        }

        using (XLWorkbook wb = new XLWorkbook())
        {
            wb.Worksheets.Add(dataTable);
            wb.Worksheets.Add(pieChartDataTable);
            using (MemoryStream stream = new MemoryStream())
            {
                wb.SaveAs(stream);
                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
        }
    }




    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


}

