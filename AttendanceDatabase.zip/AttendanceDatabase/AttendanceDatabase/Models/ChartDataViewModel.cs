﻿using System;
namespace AttendanceDatabase.Models
{
	public class ChartDataViewModel
	{
        public string Tag { get; set; }
        public int Count { get; set; }
        public double Percentage { get; set; }
    }
}

